from __future__ import annotations

import csv
import json
import re
from pathlib import Path

from engine.compressor import CompressionResult
from engine.docx_io import write_docx


CHANNELS = "AEIOU"


def safe_stem(path: Path) -> str:
    return re.sub(r'[<>:"/\\|?*]+', "_", path.stem)


def write_all_outputs(
    *,
    source_path: Path,
    source_relative: Path,
    source_text: str,
    result: CompressionResult,
    output_dir: Path,
    config: dict,
    elapsed_seconds: float,
) -> dict:
    stem = safe_stem(source_path)
    txt_path = output_dir / f"{stem}_AEIOU压缩.txt"
    docx_path = output_dir / f"{stem}_AEIOU压缩.docx"
    units_path = output_dir / f"{stem}_单位轨迹.csv"
    cycles_path = output_dir / f"{stem}_压缩循环.csv"
    summary_path = output_dir / f"{stem}_运行摘要.json"
    method_path = output_dir / f"{stem}_算法说明.txt"

    txt_path.write_text(result.text, encoding="utf-8")

    subtitle = (
        f"源文档：{source_relative}｜"
        f"{len(source_text)} → {len(result.text)} 字符｜"
        "原文抽取，不改写"
    )
    write_docx(
        docx_path,
        title=str(config["output_title"]),
        subtitle=subtitle,
        body_text=result.text,
    )

    selected = set(result.selected_indices)
    with units_path.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.writer(handle)
        writer.writerow(
            [
                "unit_index",
                "selected",
                "characters",
                "event_count",
                *CHANNELS,
                "original_text",
            ]
        )
        for unit in result.units:
            writer.writerow(
                [
                    unit.index + 1,
                    1 if unit.index in selected else 0,
                    len(unit.text),
                    unit.event_count,
                    *[f"{value:.12g}" for value in unit.vector],
                    unit.text,
                ]
            )

    with cycles_path.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.writer(handle)
        writer.writerow(
            [
                "phase",
                "step",
                "blocks_before",
                "blocks_after",
                "output_characters",
                "merged_pair_start",
                "distortion",
            ]
        )
        for record in result.cycle_records:
            writer.writerow(
                [
                    record.phase,
                    record.step,
                    record.blocks_before,
                    record.blocks_after,
                    record.output_characters,
                    "" if record.merged_pair_start is None else record.merged_pair_start,
                    "" if record.distortion is None else f"{record.distortion:.12g}",
                ]
            )

    summary = {
        "source_file": str(source_relative),
        "source_characters": len(source_text),
        "source_units": len(result.units),
        "output_characters": len(result.text),
        "selected_units": [index + 1 for index in result.selected_indices],
        "cycle_records": result.cycles_count,
        "fell_below_minimum": result.fell_below_minimum,
        "elapsed_seconds": elapsed_seconds,
        "language_model_used": False,
        "training_used": False,
        "network_used": False,
        "third_party_packages_used": False,
        "semantic_threshold_used": False,
        "output_is_original_text_only": True,
        "config": config,
    }
    summary_path.write_text(
        json.dumps(summary, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )

    method = f"""AEIOU 动态轨迹压缩：本次运行说明
============================================================

源文档
- 文件：{source_relative}
- 原文字符：{len(source_text)}
- 原文单位：{len(result.units)}

结果
- 输出字符：{len(result.text)}
- 最终原文单位：{len(result.selected_indices)}
- 循环记录：{result.cycles_count}
- 运行时间：{elapsed_seconds:.6f} 秒

本次没有使用
- 语言模型
- 神经模型训练
- 网络连接
- 关键词表
- 主题标签
- 相似度达到多少才保留
- top-k / top-p
- 人工通道权重
- 句子改写

本次使用的运行规则
1. 原文在已有句末标点和换行处分开。
2. 每个二至五连字符事件固定进入A、E、I、O、U五维载荷。
3. 初始每个原文单位是一个关系块。
4. 相邻关系块在同一轮同步两两合并。
5. 每个新关系块从自己包含的原句中重新产生代表原句。
6. 整轮会跨过输出范围时，改为逐对合并。
7. 逐对合并使用完整排序选择对代表轨迹改变最小的一对，不设内容阈值。
8. 最终原句按源文档顺序输出。
9. 低于最低字数时，沿同一条全局轨迹补入原句。
10. Word正文没有新增观点，全部来自最终压缩文字。

工程边界
- 输出范围：{config["min_output_chars"]}～{config["max_output_chars"]} 字符
- 希望靠近：{config["preferred_output_chars"]} 字符
- 事件宽度：{config["ngram_min"]}～{config["ngram_max"]} 字符
- 超长无标点单位运行切分：{config["long_unit_fallback_chars"]} 字符
"""
    method_path.write_text(method, encoding="utf-8")
    return summary
